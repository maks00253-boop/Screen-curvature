package com.example.bezelanim

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bump", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            fitsSystemWindows = true
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            setPadding(0, (16 * d).toInt(), 0, 0)
        }

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Включить службу (спец. возможности)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Switch(this).apply {
            text = "Кнопки справа"
            isChecked = prefs.getBoolean("right", true)
            setPadding(0, (16 * d).toInt(), 0, 0)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("right", checked).apply()
                BumpService.instance?.pulse(true)
            }
        })

        fun slider(title: String, key: String, def: Int, up: Boolean) {
            root.addView(label(title))
            root.addView(SeekBar(this).apply {
                max = 100
                progress = prefs.getInt(key, def)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                        prefs.edit().putInt(key, v).apply()
                        if (fromUser) BumpService.instance?.pulse(up)
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            })
        }
        slider("Высота кнопки «громкость +» (% от верха экрана)", "yUp", 25, true)
        slider("Высота кнопки «громкость −» (% от верха экрана)", "yDown", 35, false)

        root.addView(label("Двигайте ползунки — выступ покажется на выбранной высоте. " +
                "Подгоните так, чтобы он совпал с физическими кнопками."))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (BumpService.instance != null) "Служба включена ✅"
                      else "Служба выключена — включите её в спец. возможностях"
    }
}
