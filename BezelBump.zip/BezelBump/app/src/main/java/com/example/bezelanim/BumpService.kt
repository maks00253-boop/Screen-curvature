package com.example.bezelanim

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class BumpService : AccessibilityService() {

    companion object {
        var instance: BumpService? = null
        private const val MIN_SHOW_MS = 220L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { bump?.animateTo(0f) }
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var bump: BezelBumpView? = null
    private var shownAt = 0L

    override fun onServiceConnected() {
        instance = this
        if (bump != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        // TYPE_ACCESSIBILITY_OVERLAY не требует разрешения «поверх других окон»
        lp = WindowManager.LayoutParams(
            (24 * d).toInt(), (180 * d).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        bump = BezelBumpView(this).also { wm.addView(it, lp) }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val up = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> true
            KeyEvent.KEYCODE_VOLUME_DOWN -> false
            else -> return false
        }
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) show(up)   // выезжает и держится, пока кнопка зажата
        } else if (event.action == KeyEvent.ACTION_UP) {
            hideSoon()                              // прячется после отпускания
        }
        return false // громкость регулируется как обычно
    }

    private fun show(up: Boolean) {
        val v = bump ?: return
        val p = getSharedPreferences("bump", MODE_PRIVATE)
        val right = p.getBoolean("right", true)
        val pct = p.getInt(if (up) "yUp" else "yDown", if (up) 25 else 35)
        lp.gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START)
        lp.y = (resources.displayMetrics.heightPixels * pct / 100f - lp.height / 2f).toInt()
        wm.updateViewLayout(v, lp)
        v.onRight = right
        handler.removeCallbacks(hideRunnable)
        shownAt = SystemClock.uptimeMillis()
        v.animateTo(1f)
    }

    private fun hideSoon(minDelay: Long = 0) {
        val wait = maxOf(minDelay, MIN_SHOW_MS - (SystemClock.uptimeMillis() - shownAt))
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, wait)
    }

    /** Для калибровки из настроек. */
    fun pulse(up: Boolean) { show(up); hideSoon(700) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        try { bump?.let { wm.removeView(it) } } catch (_: Exception) {}
        bump = null
        super.onDestroy()
    }
}
