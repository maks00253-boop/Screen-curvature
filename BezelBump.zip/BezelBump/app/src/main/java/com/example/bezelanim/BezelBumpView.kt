package com.example.bezelanim

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator

class BezelBumpView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val path = Path()
    private var progress = 0f
    private var anim: ValueAnimator? = null

    var onRight = true
        set(value) { field = value; invalidate() }

    /** 1f — выступ выехал, 0f — спрятан. Анимация стартует с текущего состояния. */
    fun animateTo(target: Float) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(progress, target).apply {
            duration = if (target > 0f) 280 else 220
            interpolator = if (target > 0f) OvershootInterpolator(1.4f)
                           else AccelerateDecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (progress <= 0.001f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val depth = w * 0.7f * progress
        val x0 = if (onRight) w else 0f
        val x1 = if (onRight) w - depth else depth

        path.reset()
        path.moveTo(x0, 0f)
        path.cubicTo(x0, h * 0.30f, x1, h * 0.22f, x1, h * 0.5f)
        path.cubicTo(x1, h * 0.78f, x0, h * 0.70f, x0, h)
        path.close()
        canvas.drawPath(path, paint)
    }
}
